import argparse, os, json
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, r2_score
import joblib
import tensorflow as tf
from tensorflow import keras
from utils import set_seeds, ensure_dir

FEATURES = ["latitude","longitude","median_income","house_age","rooms","bedrooms","population","households"]
TARGET = "price"

def build_model(input_dim: int):
    model = keras.Sequential([
        keras.layers.Input(shape=(input_dim,)),
        keras.layers.Dense(128, activation="relu"),
        keras.layers.Dropout(0.1),
        keras.layers.Dense(64, activation="relu"),
        keras.layers.Dense(32, activation="relu"),
        keras.layers.Dense(1)
    ])
    model.compile(optimizer=keras.optimizers.Adam(learning_rate=1e-3),
                  loss="mae",
                  metrics=["mae"])
    return model

def main(args):
    set_seeds(42)
    ensure_dir(args.model_dir)

    df = pd.read_csv(args.data)
    X = df[FEATURES].values
    y = df[TARGET].values

    X_train, X_temp, y_train, y_temp = train_test_split(X, y, test_size=0.2, random_state=42)
    X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.5, random_state=42)
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_val = scaler.transform(X_val)
    X_test = scaler.transform(X_test)

    joblib.dump(scaler, os.path.join(args.model_dir, "scaler.pkl"))

    model = build_model(X_train.shape[1])

    callbacks = [
        keras.callbacks.EarlyStopping(patience=5, restore_best_weights=True, monitor="val_mae"),
        keras.callbacks.ReduceLROnPlateau(patience=3, factor=0.5, monitor="val_mae")
    ]

    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=args.epochs,
        batch_size=args.batch_size,
        verbose=2,
        callbacks=callbacks
    )

    model.save(os.path.join(args.model_dir, "model.keras"))
    # print(model.save)
    hist_df = pd.DataFrame(history.history)
    hist_df.to_csv(os.path.join(args.model_dir, "history.csv"), index=False)

    preds = model.predict(X_test).ravel()
    mae = mean_absolute_error(y_test, preds)
    r2 = r2_score(y_test, preds)

    with open(os.path.join(args.model_dir, "metrics.json"), "w") as f:
        json.dump({"mae": float(mae), "r2": float(r2)}, f, indent=2)

    print(f"Test MAE: {mae:.2f}, R2: {r2:.4f}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=str, required=True)
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--model_dir", type=str, default="artifacts")
    args = parser.parse_args()
    main(args)
