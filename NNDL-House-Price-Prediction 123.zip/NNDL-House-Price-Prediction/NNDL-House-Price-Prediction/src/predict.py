import argparse, os, json
import numpy as np
import joblib
import tensorflow as tf

FEATURES = ["latitude","longitude","median_income","house_age","rooms","bedrooms","population","households"]

def main(args):
    with open(args.input_json, "r") as f:
        record = json.load(f)

    x = np.array([[record[f] for f in FEATURES]], dtype=float)
    scaler = joblib.load(os.path.join(args.model_dir, "scaler.pkl"))
    x = scaler.transform(x)

    model = tf.keras.models.load_model(os.path.join(args.model_dir, "model.keras"))
    pred = float(model.predict(x).ravel()[0])
    print(json.dumps({"predicted_price": pred}, indent=2))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_json", type=str, required=True)
    parser.add_argument("--model_dir", type=str, default="artifacts")
    args = parser.parse_args()
    main(args)
