import argparse, os, json
import pandas as pd
import numpy as np
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.preprocessing import StandardScaler
import joblib
import tensorflow as tf

FEATURES = ["latitude","longitude","median_income","house_age","rooms","bedrooms","population","households"]
TARGET = "price"

def main(args):
    df = pd.read_csv(args.data)
    X = df[FEATURES].values
    y = df[TARGET].values

    scaler = joblib.load(os.path.join(args.model_dir, "scaler.pkl"))
    X = scaler.transform(X)

    model = tf.keras.models.load_model(os.path.join(args.model_dir, "model.keras"))
    preds = model.predict(X).ravel()

    mae = mean_absolute_error(y, preds)
    r2 = r2_score(y, preds)

    with open(os.path.join(args.model_dir, "eval_full_data.json"), "w") as f:
        json.dump({"mae": float(mae), "r2": float(r2)}, f, indent=2)

    print(f"MAE: {mae:.2f}, R2: {r2:.4f}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=str, required=True)
    parser.add_argument("--model_dir", type=str, default="artifacts")
    args = parser.parse_args()
    main(args)
