import os
import numpy as np
import joblib
import tensorflow as tf

FEATURES = ["latitude", "longitude", "median_income", "house_age", "rooms", "bedrooms", "population", "households"]

def validate_input(feature, value):
    ranges = {
        "latitude": (-90, 90),
        "longitude": (-180, 180),
        "median_income": (0, 100),  # 0 to 1M annual income
        "house_age": (0, 200),
        "rooms": (1, 50),
        "bedrooms": (0, 20),
        "population": (1, 10000),
        "households": (1, 5000)
    }
    
    if feature in ranges:
        min_val, max_val = ranges[feature]
        if value < min_val or value > max_val:
            raise ValueError(f"Value must be between {min_val} and {max_val}")

def get_user_input():
    print("\nPlease enter the following details for house price prediction:")
    print("--------------------------------------------------------")
    
    record = {}
    
    # Description and ranges for each feature
    feature_info = {
        "latitude": "Latitude (must be between -90 and 90, e.g., 37.3 for San Francisco Bay Area)",
        "longitude": "Longitude (must be between -180 and 180, e.g., -122.0 for San Francisco Bay Area)",
        "median_income": "Median income in the area (in tens of thousands, e.g., 5.2 means $52,000)",
        "house_age": "Age of the house in years (0-200)",
        "rooms": "Total number of rooms (1-50)",
        "bedrooms": "Number of bedrooms (0-20)",
        "population": "Population in the neighborhood (1-10000)",
        "households": "Number of households in the neighborhood (1-5000)"
    }
    
    for feature in FEATURES:
        while True:
            try:
                value = float(input(f"\nEnter {feature_info[feature]}: "))
                validate_input(feature, value)
                record[feature] = value
                break
            except ValueError as e:
                print(f"Error: {str(e)}")
                print("Please enter a valid number within the specified range!")
    
    return record

def main():
    try:
        # Get user input
        record = get_user_input()
        
        # Prepare input for model
        x = np.array([[record[f] for f in FEATURES]], dtype=float)
        
        # Load scaler and model
        model_dir = "artifacts"  # Look in current directory
        scaler = joblib.load(os.path.join(model_dir, "scaler.pkl"))
        x = scaler.transform(x)
        
        # Load model and make prediction
        model = tf.keras.models.load_model(os.path.join(model_dir, "model.keras"))
        pred = float(model.predict(x, verbose=0).ravel()[0])
        
        # Display results
        print("\n========================================")
        print("Input Summary:")
        print("========================================")
        for feature in FEATURES:
            print(f"{feature.title()}: {record[feature]}")
        print("\n========================================")
        print("Prediction Results:")
        print("========================================")
        print(f"Predicted House Price: ${pred:,.2f}")
        print("========================================")
        
    except Exception as e:
        print(f"\nAn error occurred: {str(e)}")
        print("Please make sure the model is trained and all files exist.")

if __name__ == "__main__":
    main()