# NNDL Mini Project — House Price Prediction (Neural Networks & Deep Learning)

A complete, ready-to-run project that predicts house prices using a **Neural Network (Keras/TensorFlow)**.

**What’s inside**
- `data/sample_housing.csv`: synthetic dataset (3,000 rows, 9 columns)
- `src/`: clean, modular training & evaluation code
- `reports/NNDL_Project_Report.docx`: well-structured project report
- `slides/NNDL_Presentation.pptx`: 10-slide presentation
- `requirements.txt`: Python dependencies
- `README.md`: setup, run, and grading helpers

## Quickstart

```bash
# 1) create & activate a venv (recommended)
python -m venv .venv
source .venv/bin/activate

# 2) install dependencies
pip install -r requirements.txt

# 3) train the model
python src/train.py --data data/sample_housing.csv --epochs 30 --batch_size 64 --model_dir artifacts

# 4) evaluate
python src/evaluate.py --data data/sample_housing.csv --model_dir artifacts

# 5) predict on a single JSON (example file created at `samples/example_input.json`)
python src/predict.py --input_json samples/example_input.json --model_dir artifacts
```

## Dataset

Columns:
- `latitude, longitude`: geo features
- `median_income`: household income proxy
- `house_age`: age in years
- `rooms, bedrooms`: housing features
- `population, households`: locality stats
- `price`: **target** (USD)

## Model

- Standardization with `sklearn` pipeline
- Dense NN (Keras): [128 → 64 → 32] ReLU + dropout, MAE loss
- EarlyStopping + ReduceLROnPlateau

## Reproducibility & Grading

- Deterministic seeds fixed in `src/utils.py`
- Clear logs & metrics written to `artifacts/history.csv`
- Saved model (`artifacts/model.keras`) + `scaler.pkl`
